package com.example.crypto_trader

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
