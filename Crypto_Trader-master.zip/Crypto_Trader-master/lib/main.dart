import 'package:crypto_trader/Screens/AuthScreen.dart';
import 'package:crypto_trader/Screens/Home.dart';
import 'package:crypto_trader/Screens/InvestDetail.dart';
import 'package:crypto_trader/Screens/StockDetail.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: Colors.green,
        accentColor: Colors.greenAccent,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: AuthScreen(),
      routes: {
        StockDetail.routeName: (ctx) => StockDetail(),
        InvestDetail.routeName: (ctx) => InvestDetail(),
      },
    );
  }
}
