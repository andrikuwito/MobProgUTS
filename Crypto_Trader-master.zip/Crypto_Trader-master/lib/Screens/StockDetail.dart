import 'package:crypto_trader/Widgets/BuyStocks.dart';
import 'package:crypto_trader/Widgets/Chart.dart';
import 'package:crypto_trader/Widgets/Stocks.dart';
import 'package:flutter/material.dart';

class StockDetail extends StatelessWidget {
  static const routeName = '/stock';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).accentColor,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.only(top: 10),
          child: Column(
            children: <Widget>[
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  IconButton(
                      icon: Icon(
                        Icons.arrow_back,
                        color: Colors.white,
                        size: 30,
                        semanticLabel: 'Back',
                      ),
                      onPressed: () {
                        Navigator.of(context).pop();
                      }),
                  SizedBox(
                    width: 100,
                  ),
                  Center(
                    child: Text(
                      "Tesla Inc.",
                      style: TextStyle(
                          fontSize: 30,
                          color: Colors.white,
                          fontWeight: FontWeight.bold),
                    ),
                  )
                ],
              ),
              SizedBox(height: 10),
              Container(
                height: 200,
                child: Container(
                  child: Chart(),
                ),
              ),
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(45.0),
                      topRight: Radius.circular(45.0),
                    ),
                  ),
                  child: ClipRRect(
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(45.0),
                        topRight: Radius.circular(45.0),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: BuyStocks(),
                      )),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
