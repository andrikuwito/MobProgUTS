import 'package:crypto_trader/Screens/AuthScreen.dart';
import 'package:crypto_trader/Widgets/CustomAppBar2.dart';
import 'package:crypto_trader/Widgets/InvestedStocks.dart';
import 'package:flutter/material.dart';

class Profile extends StatefulWidget {
  @override
  _ProfileState createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  final pkey = TextEditingController();
  final amt = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        CustomAppBar2(),
        Expanded(
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(45.0),
                topRight: Radius.circular(45.0),
              ),
            ),
            child: ClipRRect(
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(45.0),
                  topRight: Radius.circular(45.0),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: ListView(
                    children: <Widget>[
                      Column(
                        children: <Widget>[
                          Text(
                            "Krishn Kumar",
                            style: TextStyle(
                              fontSize: 30,
                            ),
                          ),
                          SizedBox(
                            height: 40,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: <Widget>[
                              Card(
                                elevation: 5,
                                shadowColor: Theme.of(context).accentColor,
                                child: Padding(
                                  padding: const EdgeInsets.all(20.0),
                                  child: Column(
                                    children: <Widget>[
                                      Text(
                                        "Crypto Balance",
                                        style: TextStyle(
                                          fontSize: 20,
                                          color: Theme.of(context).accentColor,
                                        ),
                                      ),
                                      SizedBox(
                                        height: 10,
                                      ),
                                      Text(
                                        "187 BTC",
                                        style: TextStyle(
                                          fontSize: 20,
                                          color: Theme.of(context).accentColor,
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                              Card(
                                elevation: 5,
                                shadowColor: Theme.of(context).accentColor,
                                child: Padding(
                                  padding: const EdgeInsets.all(20.0),
                                  child: Column(
                                    children: <Widget>[
                                      Text(
                                        "Crypto Invested",
                                        style: TextStyle(
                                          fontSize: 20,
                                          color: Colors.blue,
                                        ),
                                      ),
                                      SizedBox(
                                        height: 10,
                                      ),
                                      Text(
                                        "56 BTC",
                                        style: TextStyle(
                                          fontSize: 20,
                                          color: Colors.blue,
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 100,
                          ),
                          Container(
                            height: 35.0,
                            padding: EdgeInsets.symmetric(horizontal: 15),
                            child: GestureDetector(
                              onTap: () {
                                showDialog(
                                    context: context,
                                    builder: (BuildContext context) {
                                      return AlertDialog(
                                        title: Text("Load Crypto"),
                                        content: Container(
                                          height: 130,
                                          child: Column(
                                            children: <Widget>[
                                              TextField(
                                                decoration: InputDecoration(
                                                    labelText:
                                                        "Enter Public Key"),
                                                keyboardType:
                                                    TextInputType.multiline,
                                                controller: pkey,
                                              ),
                                              TextField(
                                                decoration: InputDecoration(
                                                    labelText: "Enter Amount"),
                                                keyboardType:
                                                    TextInputType.number,
                                                controller: amt,
                                              ),
                                            ],
                                          ),
                                        ),
                                        actions: <Widget>[
                                          FlatButton.icon(
                                            onPressed: () {
                                              pkey.text = "";
                                              amt.text = "";
                                              Navigator.of(context).pop();
                                            },
                                            icon: Icon(Icons.cancel),
                                            label: Text("Cancel"),
                                          ),
                                          FlatButton.icon(
                                            onPressed: () {
                                              pkey.text = "";
                                              amt.text = "";
                                              Navigator.of(context).pop();
                                            },
                                            icon: Icon(Icons.monetization_on),
                                            label: Text("Load"),
                                          ),
                                        ],
                                      );
                                    });
                              },
                              child: Material(
                                borderRadius: BorderRadius.circular(20.0),
                                shadowColor: Colors.indigoAccent,
                                color: Colors.blue,
                                elevation: 7.0,
                                child: Center(
                                  child: Text(
                                    "Load Crypto",
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 20,
                                        fontFamily: 'Montserrat'),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 40,
                          ),
                          Container(
                            height: 35.0,
                            padding: EdgeInsets.symmetric(horizontal: 15),
                            child: GestureDetector(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute<void>(
                                    builder: (BuildContext context) {
                                      return Scaffold(
                                        backgroundColor:
                                            Theme.of(context).primaryColor,
                                        body: AuthScreen(),
                                      );
                                    },
                                  ),
                                );
                              },
                              child: Material(
                                borderRadius: BorderRadius.circular(20.0),
                                shadowColor: Colors.indigoAccent,
                                color: Theme.of(context).primaryColor,
                                elevation: 7.0,
                                child: Center(
                                  child: Text(
                                    "Log Out",
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 20,
                                        fontFamily: 'Montserrat'),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                )),
          ),
        ),
      ],
    );
  }
}
