import 'package:crypto_trader/Widgets/CustomAppBar.dart';
import 'package:crypto_trader/Widgets/InvestedStocks.dart';
import 'package:flutter/material.dart';

class Invested extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        CustomAppBar(),
        Expanded(
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(45.0),
                topRight: Radius.circular(45.0),
              ),
            ),
            child: ClipRRect(
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(45.0),
                  topRight: Radius.circular(45.0),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: InvestedStocks(),
                )),
          ),
        ),
      ],
    );
  }
}
