import 'package:crypto_trader/Screens/Explore.dart';
import 'package:crypto_trader/Screens/Invested.dart';
import 'package:crypto_trader/Screens/Profile.dart';
import 'package:flutter/material.dart';
import 'package:bottom_navy_bar/bottom_navy_bar.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int currentIndex = 1;
  final List<Widget> _pages = [Invested(), Explore(), Profile()];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).accentColor,
      body: _pages[currentIndex],
      bottomNavigationBar: BottomNavyBar(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        showElevation: false,
        items: <BottomNavyBarItem>[
          BottomNavyBarItem(
              icon: Icon(Icons.monetization_on),
              title: Text('Investments'),
              activeColor: Colors.greenAccent,
              inactiveColor: Colors.black26),
          BottomNavyBarItem(
              icon: Icon(Icons.graphic_eq),
              title: Text('Explore'),
              activeColor: Colors.greenAccent,
              inactiveColor: Colors.black26),
          BottomNavyBarItem(
              icon: Icon(Icons.account_circle),
              title: Text('Profile'),
              activeColor: Colors.greenAccent,
              inactiveColor: Colors.black26),
        ],
        onItemSelected: (index) {
          setState(() {
            currentIndex = index;
          });
        },
        selectedIndex: currentIndex,
      ),
    );
  }
}
