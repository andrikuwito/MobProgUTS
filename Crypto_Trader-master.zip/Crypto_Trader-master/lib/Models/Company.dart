class Company {
  final String name;
  final String description;
  final String amt;
  final String change;
  Company({this.name, this.description, this.amt, this.change});
}
