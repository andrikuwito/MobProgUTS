import 'package:crypto_trader/Screens/InvestDetail.dart';
import 'package:flutter/material.dart';

class InvestCard extends StatelessWidget {
  final String name;
  final String description;
  final String amt;
  final String change;
  InvestCard({this.name, this.description, this.amt, this.change});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 25),
      child: InkWell(
        onTap: () {
          Navigator.of(context).pushNamed(InvestDetail.routeName);
        },
        splashColor: Theme.of(context).accentColor,
        child: Card(
          elevation: 5,
          shadowColor: Theme.of(context).accentColor,
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Icon(Icons.card_travel),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            name,
                            style: TextStyle(
                                color: Theme.of(context).primaryColor,
                                fontSize: 20),
                          ),
                          SizedBox(height: 5),
                          Text(description,
                              style: TextStyle(
                                color: Colors.grey,
                              ))
                        ],
                      ),
                    ),
                    SizedBox(
                      width: 70,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            amt,
                            style: TextStyle(
                                color: Theme.of(context).accentColor,
                                fontSize: 20),
                          ),
                          SizedBox(height: 5),
                          Text(change,
                              style: TextStyle(
                                color: Colors.blue,
                              ))
                        ],
                      ),
                    ),
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
