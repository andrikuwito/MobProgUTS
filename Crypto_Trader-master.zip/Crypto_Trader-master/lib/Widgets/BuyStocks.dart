import 'package:flutter/material.dart';

class BuyStocks extends StatefulWidget {
  @override
  _BuyStocksState createState() => _BuyStocksState();
}

class _BuyStocksState extends State<BuyStocks> {
  final myController = TextEditingController();

  @override
  void dispose() {
    // Clean up the controller when the widget is disposed.
    myController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: <Widget>[
        SizedBox(height: 20),
        Column(
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                Card(
                  elevation: 5,
                  shadowColor: Theme.of(context).accentColor,
                  child: Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Column(
                      children: <Widget>[
                        Text(
                          "Stock Prize",
                          style: TextStyle(
                              fontSize: 22,
                              color: Theme.of(context).primaryColor),
                        ),
                        Text(
                          "1.24 BTC",
                          style: TextStyle(
                              fontSize: 22,
                              color: Theme.of(context).primaryColor),
                        ),
                      ],
                    ),
                  ),
                ),
                Card(
                  elevation: 5,
                  shadowColor: Theme.of(context).accentColor,
                  child: Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Column(
                      children: <Widget>[
                        Text(
                          "Change",
                          style: TextStyle(fontSize: 22, color: Colors.blue),
                        ),
                        Text(
                          "+0.3%",
                          style: TextStyle(fontSize: 22, color: Colors.blue),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 25),
            Center(
              child: Text("Enter Investment Amount: ",
                  style: TextStyle(fontSize: 20)),
            ),
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: TextField(
                decoration: InputDecoration(labelText: "Investment Amount"),
                keyboardType: TextInputType.number,
                controller: myController,
              ),
            ),
            SizedBox(
              height: 25,
            ),
            Container(
              height: 40.0,
              child: GestureDetector(
                onTap: () {
                  Navigator.of(context).pop();
                },
                child: Material(
                  borderRadius: BorderRadius.circular(20.0),
                  shadowColor: Theme.of(context).primaryColor,
                  color: Theme.of(context).primaryColor,
                  elevation: 7.0,
                  child: Center(
                      child: Text(
                    'BUY STOCKS',
                    style: TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold),
                  )),
                ),
              ),
            ),
          ],
        )
      ],
    );
  }
}
