import 'package:flutter/material.dart';

class SellStocks extends StatefulWidget {
  @override
  _BuyStocksState createState() => _BuyStocksState();
}

class _BuyStocksState extends State<SellStocks> {
  final myController = TextEditingController();

  @override
  void dispose() {
    // Clean up the controller when the widget is disposed.
    myController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: <Widget>[
        SizedBox(height: 20),
        Column(
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                Card(
                  elevation: 5,
                  shadowColor: Theme.of(context).accentColor,
                  child: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Column(
                      children: <Widget>[
                        Text(
                          "Stock Prize",
                          style: TextStyle(
                              fontSize: 16,
                              color: Theme.of(context).primaryColor),
                        ),
                        Text(
                          "1.57 BTC",
                          style: TextStyle(
                              fontSize: 16,
                              color: Theme.of(context).primaryColor),
                        ),
                      ],
                    ),
                  ),
                ),
                Card(
                  elevation: 5,
                  shadowColor: Theme.of(context).accentColor,
                  child: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Column(
                      children: <Widget>[
                        Text(
                          "Change",
                          style: TextStyle(fontSize: 16, color: Colors.blue),
                        ),
                        Text(
                          "+4.8%",
                          style: TextStyle(fontSize: 16, color: Colors.blue),
                        ),
                      ],
                    ),
                  ),
                ),
                Card(
                  elevation: 5,
                  shadowColor: Theme.of(context).accentColor,
                  child: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Column(
                      children: <Widget>[
                        Text(
                          "Stocks Bought",
                          style: TextStyle(fontSize: 16, color: Colors.green),
                        ),
                        Text(
                          "16",
                          style: TextStyle(fontSize: 16, color: Colors.green),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 65),
            Center(
              child: Text("How many stocks you want to sell? ",
                  style: TextStyle(fontSize: 20)),
            ),
            Padding(
              padding: const EdgeInsets.all(15.0),
              child: TextField(
                decoration: InputDecoration(labelText: "No. of Stocks"),
                keyboardType: TextInputType.number,
                controller: myController,
              ),
            ),
            SizedBox(
              height: 25,
            ),
            Container(
              height: 40.0,
              child: GestureDetector(
                onTap: () {
                  Navigator.of(context).pop();
                },
                child: Material(
                  borderRadius: BorderRadius.circular(20.0),
                  shadowColor: Theme.of(context).primaryColor,
                  color: Theme.of(context).primaryColor,
                  elevation: 7.0,
                  child: Center(
                      child: Text(
                    'SELL STOCKS',
                    style: TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold),
                  )),
                ),
              ),
            ),
          ],
        )
      ],
    );
  }
}
