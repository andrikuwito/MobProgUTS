import 'package:crypto_trader/Models/Company.dart';
import 'package:crypto_trader/Widgets/StockCard.dart';
import 'package:flutter/material.dart';

class Stocks extends StatelessWidget {
  final List<Company> data = [
    Company(
        name: 'Tesla,Inc.',
        description: 'Auto Manufacturers',
        amt: '1.24 BTC',
        change: '+0.3%'),
    Company(
        name: 'Ford Motors',
        description: 'Auto Manufacturers',
        amt: '1.12 BTC',
        change: '-0.5%'),
    Company(
        name: 'Alphabet,Inc.',
        description: 'Internet Information',
        amt: '0.23 BTC',
        change: '-1.3%'),
    Company(
        name: 'Adobe Systems.',
        description: 'Aplication Software',
        amt: '0.12 BTC',
        change: '+3.1%'),
    Company(
        name: 'Under Armour',
        description: 'Apparel Clothing',
        amt: '1.57 BTC',
        change: '+4.8%'),
    Company(
        name: 'Apple,Inc.',
        description: 'Electronic Equipment',
        amt: '3.15 BTC',
        change: '-9.3%'),
    Company(
        name: 'Alibaba Group',
        description: 'Speciality Retail',
        amt: '2.13 BTC',
        change: '+1.6%'),
  ];

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        padding: EdgeInsets.all(8),
        itemCount: data.length,
        itemBuilder: (ctx, i) => StockCard(
              name: data[i].name,
              description: data[i].description,
              amt: data[i].amt,
              change: data[i].change,
            ));
  }
}
