import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

class Chart extends StatelessWidget {
  const Chart({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SfCartesianChart(
        backgroundColor: Theme.of(context).accentColor,
        plotAreaBorderWidth: 0,
        primaryXAxis: CategoryAxis(
            axisLine: AxisLine(color: Theme.of(context).primaryColor),
            majorGridLines: MajorGridLines(
                width: 0, color: Theme.of(context).primaryColor)),
        primaryYAxis: NumericAxis(
          axisLine: AxisLine(width: 0),
          majorGridLines: MajorGridLines(color: Theme.of(context).primaryColor),
          majorTickLines: MajorTickLines(color: Colors.transparent),
        ),
        series: <LineSeries>[
          LineSeries<SalesData, String>(
              animationDuration: 3000,
              dataSource: getColumnData(),
              xValueMapper: (SalesData sales, _) => sales.x,
              yValueMapper: (SalesData sales, _) => sales.y,
              markerSettings: MarkerSettings(isVisible: true),
              color: Colors.blue,
              width: 2),
        ],
        tooltipBehavior: TooltipBehavior(enable: true));
  }
}

class SalesData {
  String x;
  double y;
  SalesData(this.x, this.y);
}

dynamic getColumnData() {
  List<SalesData> columnData = <SalesData>[
    SalesData("26/8/20", 0.2),
    SalesData("30/8/20", 1.5),
    SalesData("15/9/20", 0.05),
    SalesData("20/9/20", 1.1),
    SalesData("2/10/20", 1.24),
  ];

  return columnData;
}
